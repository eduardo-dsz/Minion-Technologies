# Minion Wind Turbine Anomaly Detector

This is a Streamlit app to detect anomalies in wind turbine power output data using Isolation Forest and linear regression.

## Features
- Upload CSV with `Date/Time` and `LV ActivePower (kW)`
- Detect anomalies using Isolation Forest
- View predictions and anomalies in a chart
- Send results via email
- Download processed data

## To Run Locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Cloud
Push to a GitHub repo and connect at https://streamlit.io/cloud
